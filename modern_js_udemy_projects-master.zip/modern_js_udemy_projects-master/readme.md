# Modern JS From The Beginning Projects

> These are the main projects from my [Modern JS From The Beginning Udemy course](https://www.udemy.com/course/modern-javascript-from-the-beginning/)

- Tasklist: DOM, Local Storage
- Loan Calculator: DOM
- Number Guesser: DOM, Local Storage
- Booklist: OOP
- EasyHttp3: Ajax, Fetch, Async/Await
- Github Finder: API
- WeatherJS: API
- Profile Scroller: Generators
- Tracalorie: Module Pattern
- Microposts: Webpack & Modules
